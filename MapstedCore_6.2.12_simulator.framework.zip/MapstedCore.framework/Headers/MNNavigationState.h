//
//  MNNavigationState.h
//  positioning
//
//  Created by Parth Bhatt on 14/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MNRoutePath;
@class MNRoutePointInstruction;
@class MNPosition;
@class MNMercator;
@class MNRoutePathSegment;
@class MNDistanceTime;

#ifndef MNNavigationState_h
#define MNNavigationState_h

@interface MNNavigationState : NSObject

/**
 The destination name for the for the currently active navigation.
 */
@property (nonatomic, readonly) NSString *destinationName;

/**
 The propertyId for the for the currently active navigation.
 */
@property (nonatomic, readonly) NSInteger propertyId;

/**
 The buildingId for the for the currently active navigation.
 */
@property (nonatomic, readonly) NSInteger buildingId;

/**
 The boolean to check whether the navigation is currently active.
 */
@property (nonatomic, readonly) BOOL isActive;

/**
 The current route path for the currently active navigation.
 */
@property (nonatomic, readonly, nullable) MNRoutePath *curRoutePath;

/**
 The current instruction for the currently active navigation.
 */
@property (nonatomic, readonly, nullable) MNRoutePointInstruction *curInstruction;

/**
 The next instruction for the currently active navigation.
 */
@property (nonatomic, readonly, nullable) MNRoutePointInstruction *nextInstruction;

/**
 The after next instruction for the currently active navigation.
 */
@property (nonatomic, readonly, nullable) MNRoutePointInstruction *afterNextInstruction;

/**
 The location of the user for the currently active navigation.
 */
@property (nonatomic, readonly, nullable) MNPosition *userPoint;

/**
 The project user location for the currently active navigation.
 */
@property (nonatomic, readonly, nullable) MNMercator *projectedUserPoint;

/**
 The boolean to check whether this is first segment for the currently active navigation.
 */
@property (nonatomic, readonly) BOOL isFirstSegment;

/**
 The boolean to check whether this is intermediary segment for the currently active navigation.
 */
@property (nonatomic, readonly) BOOL isIntermediarySegment;

/**
 The boolean to check whether this is last segment for the currently active navigation.
 */
@property (nonatomic, readonly) BOOL isLastSegment;

/**
 The array of visited segments for the currently active navigation.
 */
@property (nonatomic, readonly) NSArray<MNRoutePathSegment *> *visitedSegments;

/**
 The array of upcoming segments for the currently active navigation.
 */
@property (nonatomic, readonly) NSArray<MNRoutePathSegment *> *upcomingSegments;

/**
 The current segment for the currently active navigation.
 */
@property (nonatomic, readonly, nullable) MNRoutePathSegment *curSegment;

/**
 The array of current segment's visited path for the currently active navigation.
 */
@property (nonatomic, readonly) NSArray<MNMercator *> *curSegmentVisitedPath;

/**
 The array of current segment's upcoming path for the currently active navigation.
 */
@property (nonatomic, readonly) NSArray<MNMercator *> *curSegmentUpcomingPath;

/**
 The distance and time to next instruction for the currently active navigation.
 */
@property (nonatomic, readonly) MNDistanceTime *distTimeToNextInstruction;

/**
 The distance and time to destination for the currently active navigation.
 */
@property (nonatomic, readonly) MNDistanceTime *distTimeToDestination;

/**
 */
@property (nonatomic, readonly) float distToPath;

///Creates and returns instance of the `MNNavigationState`.
/// - Parameter propertyId: The propertyId for the for the currently active navigation.
/// - Parameter buildingId: The buildingId for the for the currently active navigation.
/// - Parameter curRoutePath: The current route path for the currently active navigation.
/// - Parameter curInstruction: The current instruction for the currently active navigation.
/// - Parameter nextInstruction: The next instruction for the currently active navigation.
/// - Parameter afterNextInstruction: The after next instruction for the currently active navigation.
/// - Parameter userPoint: The location of the user for the currently active navigation.
/// - Parameter projectedUserPoint: The project user location for the currently active navigation.
/// - Parameter isActive: The boolean that suggest whether the navigation is currently active.
/// - Parameter isFirstSegment: The boolean that suggest whether this is first segment for the currently active navigation.
/// - Parameter isIntermediarySegment: The boolean that suggest whether this is intermediary segment for the currently active navigation.
/// - Parameter isLastSegment: The boolean that suggest whether this is last segment for the currently active navigation.
/// - Parameter visitedSegments: The array of visited segments for the currently active navigation.
/// - Parameter upcomingSegments: The array of upcoming segments for the currently active navigation.
/// - Parameter curSegment: The current segment for the currently active navigation.
/// - Parameter curSegmentVisitedPath: The array of current segment's visited path for the currently active navigation.
/// - Parameter curSegmentUpcomingPath: The array of current segment's upcoming path for the currently active navigation.
/// - Parameter distTimeToNextInstruction: The distance and time to next instruction for the currently active navigation.
/// - Parameter distTimeToDestination: The distance and time to destination for the currently active navigation.
/// - Parameter distToPath:
/// - Parameter destinationName: The destination name for the for the currently active navigation.
/// - Returns: an instance of `MNNavigationState`
-(nonnull MNNavigationState *)initWithPropertyId:(NSInteger)propertyId buildingId:(NSInteger)buildingId curRoutePath:(MNRoutePath *)curRoutePath curInstruction:(MNRoutePointInstruction *)curInstruction nextInstruction:(MNRoutePointInstruction *)nextInstruction afterNextInstruction:(MNRoutePointInstruction *)afterNextInstruction userPoint:(MNPosition *)userPoint projectedUserPoint:(MNMercator *)projectedUserPoint isActive:(BOOL)isActive isFirstSegment:(BOOL)isFirstSegment isIntermediarySegment:(BOOL)isIntermediarySegment isLastSegment:(BOOL)isLastSegment visitedSegments:(NSArray<MNRoutePathSegment *> *)visitedSegments upcomingSegments:(NSArray<MNRoutePathSegment *> *)upcomingSegments curSegment:(MNRoutePathSegment *)curSegment curSegmentVisitedPath:(NSArray<MNMercator *> *)curSegmentVisitedPath curSegmentUpcomingPath:(NSArray<MNMercator *> *)curSegmentUpcomingPath distTimeToNextInstruction:(MNDistanceTime *)distTimeToNextInstruction distTimeToDestination:(MNDistanceTime *)distTimeToDestination distToPath:(float)distToPath destinationName:(NSString *)destinationName;

- (NSString *)description;

@end

#endif //MNNavigationState_h
