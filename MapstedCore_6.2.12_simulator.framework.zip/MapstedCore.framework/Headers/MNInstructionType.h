//
//  MNInstructionType.h
//  positioning
//
//  Created by Parth Bhatt on 07/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#ifndef MNInstructionType_h
#define MNInstructionType_h

typedef NS_ENUM(NSInteger, MNInstructionType) {
    NoInstruction,         // No instruction
    RouteStart,            // Start of Route (first point of first segment)
    RouteDestination,      // Route Destination reached (last point of last segment)
    RouteContinue,         // Continue to next route segment
    GoUp,                  // Can be any transition type
    ElevatorUp,            // Take Elevator Up
    EscalatorUp,           // Take Escalator Up
    StairsUp,              // Take Stairs Up
    GoDown,                // Can be any transition type
    ElevatorDown,          // Take Elevator Down
    EscalatorDown,         // Take Escalator Down
    StairsDown,            // Take Stairs Down
    GoStraight,            // No significant turn
    TurnLeft,              // Turn left
    TurnRight,             // Turn right
    TurnAround,            // Sharp turn around required
    ExitBuilding,          // Exit current building
    EnterBuilding,          // Enter a building
    TakeSteps,
    TakeAccessibleRamp
    
};


#endif /* MNInstructionType_h */
