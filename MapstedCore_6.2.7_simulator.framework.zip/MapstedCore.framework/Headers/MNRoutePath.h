//
//  MNRoutePath.h
//  positioning
//
//  Created by Parth Bhatt on 07/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MNRoutePathSegment;
@class MNRoutePointInstruction;
@class MNDistanceTime;
@class MNMercatorZone;
@class MNMercator;
@class MNRouteError;
@class MapstedWaypoint;

#ifndef MNRoutePath_h
#define MNRoutePath_h

@interface MNRoutePath : NSObject

/**
 This is propertyId associated with route path
 */
@property (nonatomic, readonly) NSInteger propertyId;

/**
 This is name of that start point associated with route path
 */
@property (nonatomic, readonly, nullable) NSString *startName;

/**
 This is name of that destination point associated with route path
 */
@property (nonatomic, readonly, nullable) NSString *destinationName;

/**
 This is start waypoint associated with route path
 */
@property (nonatomic, readonly, nullable) MapstedWaypoint *startWaypoint;

/**
 This is destination waypoint associated with route path
 */
@property (nonatomic, readonly, nullable) MapstedWaypoint *destinationWaypoint;

/**
 This is list of route path segments for the given route path
 */
@property (nonatomic, readonly, nonnull) NSArray<MNRoutePathSegment *> *segments;

/**
 This is first route path segment for the given route path
 */
@property (nonatomic, readonly, nullable) MNRoutePathSegment *startSegment;

/**
 This is last route path segment for the given route path
 */
@property (nonatomic, readonly, nullable) MNRoutePathSegment *lastSegment;

/**
 This is first route point instruction for the startSegment for the given route path
 */
@property (nonatomic, readonly, nullable) MNRoutePointInstruction *startInstruction;

/**
 This is last route point instruction for the lastSegment for the given route path
 */
@property (nonatomic, readonly, nullable) MNRoutePointInstruction *lastInstruction;

/**
 This is first point based on the startSegment the given route path
 */
@property (nonatomic, readonly, nullable) MNMercatorZone *startPoint;

/**
 This is last point based on the lastSegment the given route path
 */
@property (nonatomic, readonly, nullable) MNMercatorZone *lastPoint;

/**
 This is list of alertIds for the given route path
 */
@property (nonatomic, readonly, nonnull) NSArray<NSString *> *alertIds;

/**
 This is distance time for the given route path
 */
@property (nonatomic, readonly, nullable) MNDistanceTime *distanceTime;

/**
 This is route error for the given route path
 */
@property (nonatomic, readonly, nullable) MNRouteError *routeError;

/**
 This is a boolean which suggests if the given route path is accessible route path.
 */
@property (nonatomic, readonly) BOOL isAccessible;

/**
 This is a boolean which suggests if the given route path starts from the user's current location
 */
@property (nonatomic, readonly) BOOL isFromCurrentLocation;

/// Creates an instance of `MNRoutePath`
/// - Parameter propertyId: This is propertyId associated with route path
/// - Parameter startName: This is name of that start point associated with route path
/// - Parameter destinationName: This is name of that destination point associated with route path
/// - Parameter startWayPoint: This is start waypoint associated with route path
/// - Parameter destinatioWaypoint: This is destination waypoint associated with route path
/// - Parameter routePathSegments: This is list of route path segments for the given route path
/// - Parameter alertIds: This is list of alertIds for the given route path
/// - Parameter distanceTime: This is distance time for the given route path
/// - Parameter routeError: This is route error for the given route path
/// - Parameter isAccessible: This is a boolean which suggests if the given route path is accessible route path
/// - Parameter isFromCurrentLocation: This is a boolean which suggests if the given route path starts from the user's current location
/// - Returns: The new `MNRouteError` instance.
- (nonnull MNRoutePath *)initWithPropertyId:(NSInteger)propertyId startName:(NSString * _Nullable)startName destinationName:(NSString * _Nullable)destinationName startWayPoint:(MapstedWaypoint * _Nullable)startWayPoint destinatioWaypoint:(MapstedWaypoint * _Nullable)destinatioWaypoint routePathSegments:(NSArray<MNRoutePathSegment *> * _Nonnull)routePathSegments alertIds:(NSArray<NSString *> * _Nonnull)alertIds distanceTime: (MNDistanceTime * _Nullable)distanceTime routeError:(MNRouteError * _Nullable)routeError isAccessible:(BOOL)isAccessible isFromCurrentLocation:(BOOL)isFromCurrentLocation;

@end

#endif //MNRoutePath_h
