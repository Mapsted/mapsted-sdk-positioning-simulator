//
//  MNRouteResponse.h
//  positioning
//
//  Created by Mapsted on 2019-04-09.
//  Copyright © 2019 Mapsted. All rights reserved.
//

#ifndef MNRouteResponse_h
#define MNRouteResponse_h

#import <Foundation/Foundation.h>
#import "MNRoute.h"
#import "MNRouteErrorType.h"
#import "MNRouteError.h"
#import "MNRoutingOptions.h"
#import "MNRoutingConstraints.h"

/// Represents the raw reponse for the route request
@interface MNRouteResponse : NSObject

/**
 Identifier for the property associated with the route request
 */
@property (readonly) NSInteger propertyId;

/**
 A list of routes for the request
 */
@property (readonly, nonnull) NSArray<MNRoute *> *routes;

/**
 Route error object has the details for the error
 */
@property (readonly, nullable) MNRouteError *routeError;

/**
 Routing Options object has the details for the routing options
 */
@property (readonly, nullable) MNRoutingOptions *routingOptions;

/**
 Routing Constraints object has the details for the routing constraints
 */
@property (readonly, nullable) MNRoutingConstraints *routingConstraints;

/// Creates an instance of 'MNRouteResponse' with a specified 'propertyId', array of routes and routeError string
/// - Parameter propertyId: This is propertyId found in routeresponse
/// - Parameter routes: This is array of MNRoute objects.
/// - Parameter error:  The error encountered while processing the route request
/// - Parameter routingOptions: This is MNRoutingOptions object.
/// - Parameter routingConstraints: This is routingConstraints object.
/// - Returns: The new `MNRouteResponse` instance.
//- (nonnull MNRouteResponse *)initWithPropertyId:(NSInteger)propertyId routes:(nonnull NSArray<MNRoute *> *)routes error:(MNRouteError * _Nullable)routeError;
- (nonnull instancetype)initWithPropertyId:(NSInteger)propertyId routes:(nonnull NSArray<MNRoute *> *)routes error:(MNRouteError * _Nullable)routeError routingOptions:(MNRoutingOptions * _Nullable)options routingConstraints:(MNRoutingConstraints * _Nullable)constraints;

@end

#endif //MNRouteResponse_h
