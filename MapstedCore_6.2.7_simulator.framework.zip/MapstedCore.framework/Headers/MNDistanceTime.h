//
//  MNDistanceTime.h
//  positioning
//
//  Created by Parth Bhatt on 07/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifndef MNDistanceTime_h
#define MNDistanceTime_h

@interface MNDistanceTime : NSObject
/**
  This is a attribute which represents the distance in meters.
 */
@property (nonatomic, readonly) float distanceMeters;

/**
  This is a attribute which represents the time in seconds.
 */
@property (nonatomic, readonly) float timeSeconds;

/**
  This is a attribute which represents the time in minutes.
 */
@property (nonatomic, readonly) float timeMinutes;

/**
  This is a attribute which represents the time in hours.
 */
@property (nonatomic, readonly) float timeHours;

/**
  This is a attribute which represents the distance in kilometers.
 */
@property (nonatomic, readonly) float distanceKilometers;

/**
  This is a attribute which represents the distance in feet.
 */
@property (nonatomic, readonly) float distanceFeet;

/**
  This is a attribute which represents the distance in miles.
 */
@property (nonatomic, readonly) float distanceMiles;

/// Creates an instance of 'MNDistanceTime' with a specified 'distanceMeters' and 'timeSeconds'
/// - Parameter distanceMeters: This parameter which represents the distance in meters.
/// - Parameter timeSeconds: This parameter which represents the time in seconds.
/// - Returns: The new `MNDistanceTime` instance.
- (nonnull MNDistanceTime *)initWithDistanceMeters:(float)distanceMeters timeSeconds:(float)timeSeconds;

/// Creates an instance of 'MNDistanceTime' with the difference found between 'a' and 'b'
/// - Parameter a: This is a MNDistanceTime parameter
/// - Parameter b: This is a MNDistanceTime parameter
/// - Returns: The new `MNDistanceTime` instance based on the difference found between 'a' and 'b'
+ (nonnull MNDistanceTime *)diffWithA:(MNDistanceTime * _Nonnull)a b:(MNDistanceTime * _Nonnull)b;

@end

#endif //MNDistanceTime_h
