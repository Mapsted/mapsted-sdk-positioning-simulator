//
//  MNRoute.h
//  positioning
//
//  Created by Mapsted on 2019-04-11.
//  Copyright © 2019 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MNRouteError;
@class MNRoutePath;
@class MapstedWaypoint;

typedef NS_ENUM(NSInteger, MNRoutePathType);

@interface MNRoute : NSObject

/**
 The propertyId for the route.
 */
@property (nonatomic, readonly) NSInteger propertyId;

/**
 The name for the start of the route.
 */
@property (nonatomic, readonly, nullable) NSString *startName;

/**
 The name for the destination of the route.
 */
@property (nonatomic, readonly, nullable) NSString *destinationName;

/**
 The start waypoint of the route.
 */
@property (nonatomic, readonly, nullable) MapstedWaypoint *startWaypoint;

/**
 The destination waypoint of the route.
 */
@property (nonatomic, readonly, nullable) MapstedWaypoint *destinationWaypoint;

/**
 The optimal route path of the route.
 */
@property (nonatomic, readonly, nullable) MNRoutePath *optimalRoute;

/**
 The accessible route path of the route.
 */
@property (nonatomic, readonly, nullable) MNRoutePath *accessibleRoute;

/**
 The route path which bypasses all the level transition route options.
 */
@property (nonatomic, readonly, nullable) MNRoutePath *bypassLevelTransitionsRoute;

/**
 The route path which bypasses all the alerts on property.
 */
@property (nonatomic, readonly, nullable) MNRoutePath *bypassAlertsRoute;

/**
 The route error object contains the details of any error like error type and error message.
 */
@property (nonatomic, readonly, nullable) MNRouteError *routeError;

/**
 This is used to determine if the route start from user's current location or not.
 */
@property (readonly) BOOL isFromCurrentLocation;

/**
 Initialization method for the Route object
 */
- (nonnull MNRoute *)initWithPropertyId:(NSInteger)propertyId startName:(NSString * _Nullable)startName destinationName:(NSString * _Nullable)destinationName startWaypoint:(MapstedWaypoint * _Nullable)startWaypoint destinationWaypoint:(MapstedWaypoint * _Nullable)destinationWaypoint optimalRoute:(MNRoutePath * _Nullable)optimalRoute accessibleRoute:(MNRoutePath * _Nullable)accessibleRoute bypassLevelTransitionsRoute:(MNRoutePath * _Nullable)bypassLevelTransitionsRoute bypassAlertsRoute:(MNRoutePath * _Nullable)bypassAlertsRoute routeError:(MNRouteError * _Nullable)routeError isFromCurrentLocation:(BOOL)isFromCurrentLocation;

/**
 This method is used to get the route path based on type of route path.
 */
- (nullable MNRoutePath *)getRoutePathForType:(MNRoutePathType)routePathType;

@end

