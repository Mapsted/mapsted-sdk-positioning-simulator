//
//  MNRoutePathSegment.h
//  positioning
//
//  Created by Parth Bhatt on 08/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MNRouteSegmentType.h"

@class MNMercator;
@class MNRoutePointInstruction;
@class MNDistanceTime;

//typedef NS_ENUM(NSInteger, MNRouteSegmentType);

@interface MNRoutePathSegment : NSObject
/**
 This is propertyId associated with route path segment
 */
@property (nonatomic, readonly) NSInteger propertyId;

/**
 This is buildingId associated with route path segment
 */
@property (nonatomic, readonly) NSInteger buildingId;

/**
 This is floorId associated with route path segment
 */
@property (nonatomic, readonly) NSInteger floorId;

/**
 This is segment type enum associated with route path segment
 */
@property (nonatomic, readonly) MNRouteSegmentType segmentType;

/**
 This is array of mercator points associated with route path segment
 */
@property (nonatomic, readonly, nonnull) NSArray<MNMercator *> *points;

/**
 This is array of mercator points associated with route path segment
 */
@property (nonatomic, readonly, nonnull) NSArray<MNRoutePointInstruction *> *instructions;

/**
 This is distance time for the route path segment
 */
@property (nonatomic, readonly, nullable) MNDistanceTime *distanceTime;

/**
 This suggest that this route path segment is accessible or not.
 */
@property (readonly) BOOL isAccessible;

/// Creates an instance of `MNRoutePathSegment` with 'propertyId', 'buildingId', 'floorId', 'points', 'instructions', 'distanceTime' and 'isAccessible'.
/// - Parameter propertyId: This is propertyId associated with the route path segment
/// - Parameter buildingId: This is buildingId associated with the route path segment
/// - Parameter floorId: This is floorId associated with the route path segment
/// - Parameter points: This is array of points associated with the route path segment
/// - Parameter instructions: This is array of instructions associated with the route path segment
/// - Parameter distanceTime: This is distance time for the route path segment
/// - Parameter isAccessible: This is acessible or not for the route path segment
/// - Returns: The new `MNRoutePathSegment` with 'instructionType', 'text' and 'image'.
- (nonnull MNRoutePathSegment *)initWithPropertyId:(NSInteger)propertyId buildingId:(NSInteger)buildingId floorId:(NSInteger)floorId points:(NSArray<MNMercator *> * _Nonnull)points instructions:(NSArray<MNRoutePointInstruction *> * _Nonnull)instructions distanceTime:(MNDistanceTime * _Nullable)distanceTime isAccessible:(BOOL)isAccessible;
@end
