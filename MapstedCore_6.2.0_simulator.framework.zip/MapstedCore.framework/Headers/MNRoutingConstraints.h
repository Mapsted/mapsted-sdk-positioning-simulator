//
//  MNRoutingConstraints.h
//  positioning
//
//  Created by Pooja Trivedi on 12/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//


#import <Foundation/Foundation.h>

@class MNRoutingImpact;

@interface MNRoutingConstraints : NSObject

/**
 This is array of impacts for the Routing Constriants. Impacts are of type MNRoutingImpact.
 */
@property (nonatomic, strong, readonly, nonnull) NSArray<MNRoutingImpact *> *impacts;

@property (nonatomic, strong, nonnull) NSString *accessLevelId;


/// Creates an instance of `MNRoutingConstraints`
/// - Parameter impacts: This is array of impacts for the Routing Constriants. Impacts are of type MNRoutingImpact.
/// - Parameter roleId: This is roleId of type string.
/// - Returns: instance of `MNRoutingConstraints`
- (nonnull instancetype)initWithImpacts:(NSArray<MNRoutingImpact *> * _Nullable)impacts accessLevelId:(NSString * _Nullable)accessLevelId;

// Returns an empty instance 
+ (nonnull MNRoutingConstraints *)emptyInstance;

- (void)setAccessLevelId:(NSString *_Nullable)accessLevelId;
@end
