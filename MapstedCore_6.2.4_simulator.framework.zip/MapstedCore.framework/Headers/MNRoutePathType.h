//
//  MNRoutePathType.h
//  positioning
//
//  Created by Pooja Trivedi on 09/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#ifndef MNRoutePathType_h
#define MNRoutePathType_h
typedef NS_ENUM(NSInteger, MNRoutePathType) {
    OptimalRoute,
    AccessibleRoute,
    BypassLevelTransitionsRoute,
    BypassAlertsRoute
};

#endif /* MNRoutePathType_h */
