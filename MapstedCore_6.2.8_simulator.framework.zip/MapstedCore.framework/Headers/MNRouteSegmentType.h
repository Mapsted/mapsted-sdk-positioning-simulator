//
//  MNRouteSegmentType.h
//  positioning
//
//  Created by Parth Bhatt on 08/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#ifndef MNRouteSegmentType_h
#define MNRouteSegmentType_h

typedef NS_ENUM(NSInteger, MNRouteSegmentType) {
    ROUTE_OUTSIDE_PROPERTY,   // not used
    ROUTE_WITHIN_PROPERTY,
    ROUTE_WITHIN_BUILDING     // floor segment
};

#endif /* MNRouteSegmentType_h */
