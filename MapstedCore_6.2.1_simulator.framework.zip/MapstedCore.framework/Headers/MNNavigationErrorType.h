//
//  MNNavigationErrorType.h
//  positioning
//
//  Created by Parth Bhatt on 14/05/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

#ifndef MNNavigationErrorType_h
#define MNNavigationErrorType_h

typedef NS_ENUM(NSInteger, MNNavigationErrorType) {
    NavigationErrorSuccess,
    NavigationErrorNullRoutePath,                 // Null RoutePath was provided
    NavigationErrorCurrentLocationUnknown,        // User location is not known, so navigation failed
    NavigationErrorRequestNotFromCurrentLocation, // RoutePath is not from current location, not valid for navigation
    NavigationErrorSetupFailed,                   // NavigationState setup failed (should not happen)
};


#endif /* MNNavigationErrorType_h */
