//
//  SafeHandler.h
//  positioning
//
//  Created by Parth Bhatt on 02/02/26.
//  Copyright © 2026 Mapsted. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SafeHandler : NSObject

/// Executes a block safely, catching both Obj-C (@throw) and C++ (throw) exceptions.
+ (BOOL)performSafeBlock:(void(^)(void))block error:(__autoreleasing NSError **)error;

@end

NS_ASSUME_NONNULL_END
