//
//  MNIdType.h
//  positioning
//
//  Created by Tianyun Shan on 2019-01-04.
//  Copyright © 2019 Mapsted. All rights reserved.
//

#ifndef MNIdType_h
#define MNIdType_h

typedef NS_ENUM(NSInteger, MNIdType) {
  MNIdTypeNotFound = -1
};

#endif /* MNIdType_h */
