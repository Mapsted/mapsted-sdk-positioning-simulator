//
//  UserRoleAccess.h
//  positioning
//
//  Created by Pooja Trivedi on 02/06/25.
//  Copyright © 2025 Mapsted. All rights reserved.
//

//#import <Foundation/Foundation.h>
//
//NS_ASSUME_NONNULL_BEGIN
//
//@interface MNUserRoleAccess : NSObject
//
///// Key: NSNumber (propertyId), Value: NSString (roleId)
//@property (nonatomic, strong) NSDictionary<NSNumber *, NSString *> *propertyRoleIdMap;
//
//- (instancetype)initWithPropertyRoleIdMap:(NSDictionary<NSNumber *, NSString *> *)map;
//
//@end
//
//NS_ASSUME_NONNULL_END

// MNUserRoleAccess.h
#import <Foundation/Foundation.h>
#import "MNRoleAccessPair.h"

NS_ASSUME_NONNULL_BEGIN

@interface MNUserRoleAccess : NSObject

/// Key: NSNumber (propertyId), Value: MNRoleAccessPair
@property (nonatomic, strong) NSDictionary<NSNumber *, MNRoleAccessPair *> *propertyRoleAccessMap;

- (instancetype)initWithPropertyRoleAccessMap:(NSDictionary<NSNumber *, MNRoleAccessPair *> *)map;

@end

NS_ASSUME_NONNULL_END
